# modules/transfer_handler.py

import os
import time
import zipfile
import shutil
import psutil

def transfer_files_to_usb(display_text):
    log_folder = "/home/mobase/Can_FD/Report"
    usb_root = "/media/mobase"

    try:
        devices = [d for d in os.listdir(usb_root) if os.path.ismount(os.path.join(usb_root, d))]
        if not devices:
            display_text("No USB Found")
            time.sleep(2)
            return

        usb_path = os.path.join(usb_root, devices[0])
        display_text("USB Found")
        time.sleep(1)

        zip_name = f"DiagnosticBackup_{int(time.time())}.zip"
        zip_path = f"/tmp/{zip_name}"

        display_text("Zipping files...")
        time.sleep(1)

        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, _, files in os.walk(log_folder):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, log_folder)
                    zipf.write(file_path, arcname)

        zip_size = os.path.getsize(zip_path)
        usage = psutil.disk_usage(usb_path)

        if usage.free < zip_size:
            display_text("Not enough space\non USB")
            os.remove(zip_path)
            time.sleep(2)
            return

        display_text("Copying to USB...")
        time.sleep(1)
        shutil.copy2(zip_path, usb_path)
        os.remove(zip_path)

        display_text("Transfer Complete!")
        time.sleep(2)

    except Exception as e:
        display_text(f"Error:\n{str(e)[:20]}")
        time.sleep(3)
