import json
import logging

def load_config(file_path):
    try:
        with open(file_path, 'r') as file:
            config = json.load(file)
            logging.info("Config loaded successfully.")
            return config
    except FileNotFoundError:
        logging.error(f"Configuration file not found: {file_path}")
        raise
    except json.JSONDecodeError as e:
        logging.error(f"Invalid JSON in config: {e}")
        raise
