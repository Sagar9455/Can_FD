import csv
import logging
from collections import defaultdict

def parse_test_cases(filepath="test_cases.txt"):
    test_cases = []
    grouped_cases = defaultdict(list)

    try:
        with open(filepath, "r") as f:
            reader = csv.reader(f)
            next(reader)  # Skip header

            for line_number, row in enumerate(reader, start=2):
                try:
                    row = [col.strip() for col in row]

                    if not row or len(row) < 5:
                        logging.warning(f"Skipping line {line_number}: Too short or empty - {row}")
                        continue
                    if row[0].startswith("#"):
                        logging.info(f"Skipping line {line_number}: Comment - {row}")
                        continue

                    if len(row) != 5:
                        logging.warning(f"Malformed test case at line {line_number}: {row}")
                        continue

                    test_cases.append(row)

                except Exception as e:
                    logging.error(f"Error reading line {line_number}: {row} -> {e}")

        for row in test_cases:
            grouped_cases[row[0]].append(row)

        logging.info(f"Parsed {len(grouped_cases)} test groups from {filepath}")
        return grouped_cases

    except FileNotFoundError:
        logging.error(f"Test case file not found: {filepath}")
        return {}

    except Exception as e:
        logging.exception(f"Unhandled exception during test case parsing: {e}")
        return {}
