import can
import isotp
import time
import logging
import csv
import threading

from udsoncan.client import Client
from udsoncan.connections import PythonIsoTpConnection
from udsoncan.configs import default_client_config
from udsoncan.exceptions import TimeoutException, NegativeResponseException

from report_generator import generate_report
from oled_display import display_text

class UDSClient:
    def __init__(self, config):
        can_cfg = config['uds']['can']
        isotp_cfg = config['uds']['isotp']
        timing_cfg = config['uds']['timing']
        self.uds_config = config['uds']

        self.tx_id = int(can_cfg['tx_id'], 16)
        self.rx_id = int(can_cfg['rx_id'], 16)
        self.channel = can_cfg['channel']
        self.iface = can_cfg['interface']
        self.enable_tester_present = config['uds'].get("enable_tester_present", True)

        self.bus = can.interface.Bus(channel=self.channel, bustype=self.iface, fd=can_cfg.get('can_fd', False))

        addr_mode = isotp.AddressingMode.Extended_29bits if can_cfg.get('is_extended') else isotp.AddressingMode.Normal_11bits
        address = isotp.Address(addr_mode, txid=self.tx_id, rxid=self.rx_id)

        self.stack = isotp.CanStack(bus=self.bus, address=address, params=isotp_cfg)
        self.conn = PythonIsoTpConnection(self.stack)

        self.start_time = time.time()

        self.client_config = default_client_config.copy()
        self.client_config['p2_timeout'] = timing_cfg.get('p2_client', 500) / 1000.0
        self.client_config['p2_star_timeout'] = timing_cfg.get('p2_extended_client', 5000) / 1000.0
        self.client_config['s3_client_timeout'] = timing_cfg.get('s3_client', 3000) / 1000.0

        self._tester_present_running = False
        self._tester_thread = None

    def get_canoe_timestamp(self):
        return f"{time.time() - self.start_time:.6f}"

    def _tester_present_loop(self, client, interval=2):
        while self._tester_present_running:
            try:
                client.tester_present()
                logging.debug("Tester Present sent (loop)")
            except Exception as e:
                logging.warning(f"Tester Present loop error: {e}")
            time.sleep(interval)

    def start_tester_present_loop(self, client):
        self._tester_present_running = True
        self._tester_thread = threading.Thread(target=self._tester_present_loop, args=(client,))
        self._tester_thread.daemon = True
        self._tester_thread.start()

    def stop_tester_present_loop(self):
        self._tester_present_running = False
        if self._tester_thread and self._tester_thread.is_alive():
            self._tester_thread.join()

     def get_ecu_information(self):
    tester_present = int(self.uds_config.get("tester_present"), 16)
    default_session = int(self.uds_config.get("default_session"), 16)
    extended_session = int(self.uds_config.get("extended_session"), 16)
    dids = self.uds_config.get("data_identifiers", {})

    self.send_raw([0x3E, 0x00])  # Tester Present
    self.send_raw([0x10, default_session])
    self.send_raw([0x10, extended_session])

    for did_hex in dids:
        did = int(did_hex, 16)
        response = self.send_raw([0x22, (did >> 8) & 0xFF, did & 0xFF])
        display_value = response[3:] if response else "No Resp"
        self.oled.display_text(f"{dids[did_hex]}: {display_value}")
        time.sleep(1)
    

    
    def run_testcase():
        
    os.system('sudo ip link set can0 down')
    os.system('sudo ip link set can0 up type can bitrate 500000 dbitrate 1000000 restart-ms 1000 berr-reporting on fd on')
    os.system('sudo ifconfig can0 up')

    logging.basicConfig(level=logging.INFO)
    logging.getLogger('udsoncan').setLevel(logging.WARNING)
    logging.getLogger('isotp').setLevel(logging.WARNING)

    isotp_params = {
        'stmin': 32,
        'blocksize': 8,
        'tx_padding': 0x00,
        'can_fd': True,
        'bitrate_switch': True
    }

    config = dict(udsoncan.configs.default_client_config)
    config["data_identifiers"] = {
        0xF101: udsoncan.AsciiCodec(4),
        0xF100: udsoncan.AsciiCodec(4),
        0xF1DD: udsoncan.AsciiCodec(4),
        0xF187: udsoncan.AsciiCodec(9),
        0xF1AA: udsoncan.AsciiCodec(4),
        0xF1B1: udsoncan.AsciiCodec(4),
        0xF193: udsoncan.AsciiCodec(4),
        0xF120: udsoncan.AsciiCodec(16),
        0xF18B: udsoncan.AsciiCodec(4),
        0xF102: udsoncan.AsciiCodec(8),
        0xF187: udsoncan.AsciiCodec(9),
    }

    interface = "can0"
    bus = can.interface.Bus(channel=interface, bustype="socketcan", fd=True)
    bus.set_filters([{"can_id": 0x7A8, "can_mask": 0xFFF}])
    tp_addr = isotp.Address(isotp.AddressingMode.Normal_11bits, txid=0x7A0, rxid=0x7A8)
    stack = isotp.CanStack(bus=bus, address=tp_addr, params=isotp_params)
    conn = PythonIsoTpConnection(stack)

    report = []
    with Client(conn, request_timeout=2, config=config) as client:
        client.change_session(0x03)

        for tc_id, steps in grouped_cases.items():
            for step in steps:
                _, step_desc, service, subfunc, expected = step
                service_int = int(service, 16)
                subfunc_int = int(subfunc, 16)

                expected_bytes = [int(b, 16) for b in expected.strip().split()]
                status = "Fail"
                failure_reason = "-"
                timestamp = time.strftime('%H:%M:%S', time.localtime())
                response_timestamp = timestamp

                try:
                    response = None
                    if service_int == 0x10:
                        response = client.change_session(subfunc_int)
                    elif service_int == 0x11:
                        response = client.ecu_reset(subfunc_int)
                    elif service_int == 0x22:
                        response = client.read_data_by_identifier(subfunc_int)
                    else:
                        raise ValueError(f"Unsupported service: {service}")

                    response_timestamp = time.strftime('%H:%M:%S', time.localtime())

                    if not response.positive:
                        failure_reason = f"NRC: {hex(response.code)}"
                    else:
                        actual_bytes = list(response.original_payload)
                        if actual_bytes[:len(expected_bytes)] == expected_bytes:
                            status = "Pass"
                        else:
                            failure_reason = (
                                f"Expected: {' '.join(format(b, '02X') for b in expected_bytes)}, "
                                f"Got: {' '.join(format(b, '02X') for b in actual_bytes)}"
                            )

                except Exception as e:
                    response_timestamp = time.strftime('%H:%M:%S', time.localtime())
                    failure_reason = str(e)

                # OLED display update
                display_msg = f"{tc_id}\n{step_desc[:50]}\n{status}"
                display_text(display_msg)
                time.sleep(2)

                if status == "Fail":
                    display_text(f"FAILED\n{failure_reason[:20]}", y=0)
                    time.sleep(2)

                report.append({
                    "id": tc_id,
                    "timestamp": timestamp,
                    "response_timestamp": response_timestamp,
                    "description": step_desc,
                    "type": "Request Sent",
                    "status": status,
                    "failure_reason": failure_reason
                })

    filename = f"UDS_Report_{int(time.time())}.html"
    generate_report(convert_report(report), filename=filename)
    display_text("Report Done!\n" + filename[:16])
    import can
import isotp
import time
import logging
import csv
import threading

from udsoncan.client import Client
from udsoncan.connections import PythonIsoTpConnection
from udsoncan.configs import default_client_config
from udsoncan.exceptions import TimeoutException, NegativeResponseException

from report_generator import generate_report
from oled_display import display_text

class UDSClient:
    def __init__(self, config):
        can_cfg = config['uds']['can']
        isotp_cfg = config['uds']['isotp']
        timing_cfg = config['uds']['timing']
        self.uds_config = config['uds']

        self.tx_id = int(can_cfg['tx_id'], 16)
        self.rx_id = int(can_cfg['rx_id'], 16)
        self.channel = can_cfg['channel']
        self.iface = can_cfg['interface']
        self.enable_tester_present = config['uds'].get("enable_tester_present", True)

        self.bus = can.interface.Bus(channel=self.channel, bustype=self.iface, fd=can_cfg.get('can_fd', False))

        addr_mode = isotp.AddressingMode.Extended_29bits if can_cfg.get('is_extended') else isotp.AddressingMode.Normal_11bits
        address = isotp.Address(addr_mode, txid=self.tx_id, rxid=self.rx_id)

        self.stack = isotp.CanStack(bus=self.bus, address=address, params=isotp_cfg)
        self.conn = PythonIsoTpConnection(self.stack)

        self.start_time = time.time()

        self.client_config = default_client_config.copy()
        self.client_config['p2_timeout'] = timing_cfg.get('p2_client', 500) / 1000.0
        self.client_config['p2_star_timeout'] = timing_cfg.get('p2_extended_client', 5000) / 1000.0
        self.client_config['s3_client_timeout'] = timing_cfg.get('s3_client', 3000) / 1000.0

        self._tester_present_running = False
        self._tester_thread = None

    def get_canoe_timestamp(self):
        return f"{time.time() - self.start_time:.6f}"

    def _tester_present_loop(self, client, interval=2):
        while self._tester_present_running:
            try:
                client.tester_present()
                logging.debug("Tester Present sent (loop)")
            except Exception as e:
                logging.warning(f"Tester Present loop error: {e}")
            time.sleep(interval)

    def start_tester_present_loop(self, client):
        self._tester_present_running = True
        self._tester_thread = threading.Thread(target=self._tester_present_loop, args=(client,))
        self._tester_thread.daemon = True
        self._tester_thread.start()

    def stop_tester_present_loop(self):
        self._tester_present_running = False
        if self._tester_thread and self._tester_thread.is_alive():
            self._tester_thread.join()

     def get_ecu_information(self):
    tester_present = int(self.uds_config.get("tester_present"), 16)
    default_session = int(self.uds_config.get("default_session"), 16)
    extended_session = int(self.uds_config.get("extended_session"), 16)
    dids = self.uds_config.get("data_identifiers", {})

    self.send_raw([0x3E, 0x00])  # Tester Present
    self.send_raw([0x10, default_session])
    self.send_raw([0x10, extended_session])

    for did_hex in dids:
        did = int(did_hex, 16)
        response = self.send_raw([0x22, (did >> 8) & 0xFF, did & 0xFF])
        display_value = response[3:] if response else "No Resp"
        self.oled.display_text(f"{dids[did_hex]}: {display_value}")
        time.sleep(1)
    

    
    def run_testcase():
        
    os.system('sudo ip link set can0 down')
    os.system('sudo ip link set can0 up type can bitrate 500000 dbitrate 1000000 restart-ms 1000 berr-reporting on fd on')
    os.system('sudo ifconfig can0 up')

    logging.basicConfig(level=logging.INFO)
    logging.getLogger('udsoncan').setLevel(logging.WARNING)
    logging.getLogger('isotp').setLevel(logging.WARNING)

    isotp_params = {
        'stmin': 32,
        'blocksize': 8,
        'tx_padding': 0x00,
        'can_fd': True,
        'bitrate_switch': True
    }

    config = dict(udsoncan.configs.default_client_config)
    config["data_identifiers"] = {
        0xF101: udsoncan.AsciiCodec(4),
        0xF100: udsoncan.AsciiCodec(4),
        0xF1DD: udsoncan.AsciiCodec(4),
        0xF187: udsoncan.AsciiCodec(9),
        0xF1AA: udsoncan.AsciiCodec(4),
        0xF1B1: udsoncan.AsciiCodec(4),
        0xF193: udsoncan.AsciiCodec(4),
        0xF120: udsoncan.AsciiCodec(16),
        0xF18B: udsoncan.AsciiCodec(4),
        0xF102: udsoncan.AsciiCodec(8),
        0xF187: udsoncan.AsciiCodec(9),
    }

    interface = "can0"
    bus = can.interface.Bus(channel=interface, bustype="socketcan", fd=True)
    bus.set_filters([{"can_id": 0x7A8, "can_mask": 0xFFF}])
    tp_addr = isotp.Address(isotp.AddressingMode.Normal_11bits, txid=0x7A0, rxid=0x7A8)
    stack = isotp.CanStack(bus=bus, address=tp_addr, params=isotp_params)
    conn = PythonIsoTpConnection(stack)

    report = []
    with Client(conn, request_timeout=2, config=config) as client:
        client.change_session(0x03)

        for tc_id, steps in grouped_cases.items():
            for step in steps:
                _, step_desc, service, subfunc, expected = step
                service_int = int(service, 16)
                subfunc_int = int(subfunc, 16)

                expected_bytes = [int(b, 16) for b in expected.strip().split()]
                status = "Fail"
                failure_reason = "-"
                timestamp = time.strftime('%H:%M:%S', time.localtime())
                response_timestamp = timestamp

                try:
                    response = None
                    if service_int == 0x10:
                        response = client.change_session(subfunc_int)
                    elif service_int == 0x11:
                        response = client.ecu_reset(subfunc_int)
                    elif service_int == 0x22:
                        response = client.read_data_by_identifier(subfunc_int)
                    else:
                        raise ValueError(f"Unsupported service: {service}")

                    response_timestamp = time.strftime('%H:%M:%S', time.localtime())

                    if not response.positive:
                        failure_reason = f"NRC: {hex(response.code)}"
                    else:
                        actual_bytes = list(response.original_payload)
                        if actual_bytes[:len(expected_bytes)] == expected_bytes:
                            status = "Pass"
                        else:
                            failure_reason = (
                                f"Expected: {' '.join(format(b, '02X') for b in expected_bytes)}, "
                                f"Got: {' '.join(format(b, '02X') for b in actual_bytes)}"
                            )

                except Exception as e:
                    response_timestamp = time.strftime('%H:%M:%S', time.localtime())
                    failure_reason = str(e)

                # OLED display update
                display_msg = f"{tc_id}\n{step_desc[:50]}\n{status}"
                display_text(display_msg)
                time.sleep(2)

                if status == "Fail":
                    display_text(f"FAILED\n{failure_reason[:20]}", y=0)
                    time.sleep(2)

                report.append({
                    "id": tc_id,
                    "timestamp": timestamp,
                    "response_timestamp": response_timestamp,
                    "description": step_desc,
                    "type": "Request Sent",
                    "status": status,
                    "failure_reason": failure_reason
                })

    filename = f"UDS_Report_{int(time.time())}.html"
    generate_report(convert_report(report), filename=filename)
    display_text("Report Done!\n" + filename[:16])
    import can
import isotp
import time
import logging
import csv
import threading

from udsoncan.client import Client
from udsoncan.connections import PythonIsoTpConnection
from udsoncan.configs import default_client_config
from udsoncan.exceptions import TimeoutException, NegativeResponseException

from report_generator import generate_report
from oled_display import display_text

class UDSClient:
    def __init__(self, config):
        can_cfg = config['uds']['can']
        isotp_cfg = config['uds']['isotp']
        timing_cfg = config['uds']['timing']
        self.uds_config = config['uds']

        self.tx_id = int(can_cfg['tx_id'], 16)
        self.rx_id = int(can_cfg['rx_id'], 16)
        self.channel = can_cfg['channel']
        self.iface = can_cfg['interface']
        self.enable_tester_present = config['uds'].get("enable_tester_present", True)

        self.bus = can.interface.Bus(channel=self.channel, bustype=self.iface, fd=can_cfg.get('can_fd', False))

        addr_mode = isotp.AddressingMode.Extended_29bits if can_cfg.get('is_extended') else isotp.AddressingMode.Normal_11bits
        address = isotp.Address(addr_mode, txid=self.tx_id, rxid=self.rx_id)

        self.stack = isotp.CanStack(bus=self.bus, address=address, params=isotp_cfg)
        self.conn = PythonIsoTpConnection(self.stack)

        self.start_time = time.time()

        self.client_config = default_client_config.copy()
        self.client_config['p2_timeout'] = timing_cfg.get('p2_client', 500) / 1000.0
        self.client_config['p2_star_timeout'] = timing_cfg.get('p2_extended_client', 5000) / 1000.0
        self.client_config['s3_client_timeout'] = timing_cfg.get('s3_client', 3000) / 1000.0

        self._tester_present_running = False
        self._tester_thread = None

    def get_canoe_timestamp(self):
        return f"{time.time() - self.start_time:.6f}"

    def _tester_present_loop(self, client, interval=2):
        while self._tester_present_running:
            try:
                client.tester_present()
                logging.debug("Tester Present sent (loop)")
            except Exception as e:
                logging.warning(f"Tester Present loop error: {e}")
            time.sleep(interval)

    def start_tester_present_loop(self, client):
        self._tester_present_running = True
        self._tester_thread = threading.Thread(target=self._tester_present_loop, args=(client,))
        self._tester_thread.daemon = True
        self._tester_thread.start()

    def stop_tester_present_loop(self):
        self._tester_present_running = False
        if self._tester_thread and self._tester_thread.is_alive():
            self._tester_thread.join()

     def get_ecu_information(self):
    tester_present = int(self.uds_config.get("tester_present"), 16)
    default_session = int(self.uds_config.get("default_session"), 16)
    extended_session = int(self.uds_config.get("extended_session"), 16)
    dids = self.uds_config.get("data_identifiers", {})

    self.send_raw([0x3E, 0x00])  # Tester Present
    self.send_raw([0x10, default_session])
    self.send_raw([0x10, extended_session])

    for did_hex in dids:
        did = int(did_hex, 16)
        response = self.send_raw([0x22, (did >> 8) & 0xFF, did & 0xFF])
        display_value = response[3:] if response else "No Resp"
        self.oled.display_text(f"{dids[did_hex]}: {display_value}")
        time.sleep(1)
    

    
    def run_testcase():
        
    os.system('sudo ip link set can0 down')
    os.system('sudo ip link set can0 up type can bitrate 500000 dbitrate 1000000 restart-ms 1000 berr-reporting on fd on')
    os.system('sudo ifconfig can0 up')

    logging.basicConfig(level=logging.INFO)
    logging.getLogger('udsoncan').setLevel(logging.WARNING)
    logging.getLogger('isotp').setLevel(logging.WARNING)

    isotp_params = {
        'stmin': 32,
        'blocksize': 8,
        'tx_padding': 0x00,
        'can_fd': True,
        'bitrate_switch': True
    }

    config = dict(udsoncan.configs.default_client_config)
    config["data_identifiers"] = {
        0xF101: udsoncan.AsciiCodec(4),
        0xF100: udsoncan.AsciiCodec(4),
        0xF1DD: udsoncan.AsciiCodec(4),
        0xF187: udsoncan.AsciiCodec(9),
        0xF1AA: udsoncan.AsciiCodec(4),
        0xF1B1: udsoncan.AsciiCodec(4),
        0xF193: udsoncan.AsciiCodec(4),
        0xF120: udsoncan.AsciiCodec(16),
        0xF18B: udsoncan.AsciiCodec(4),
        0xF102: udsoncan.AsciiCodec(8),
        0xF187: udsoncan.AsciiCodec(9),
    }

    interface = "can0"
    bus = can.interface.Bus(channel=interface, bustype="socketcan", fd=True)
    bus.set_filters([{"can_id": 0x7A8, "can_mask": 0xFFF}])
    tp_addr = isotp.Address(isotp.AddressingMode.Normal_11bits, txid=0x7A0, rxid=0x7A8)
    stack = isotp.CanStack(bus=bus, address=tp_addr, params=isotp_params)
    conn = PythonIsoTpConnection(stack)

    report = []
    with Client(conn, request_timeout=2, config=config) as client:
        client.change_session(0x03)

        for tc_id, steps in grouped_cases.items():
            for step in steps:
                _, step_desc, service, subfunc, expected = step
                service_int = int(service, 16)
                subfunc_int = int(subfunc, 16)

                expected_bytes = [int(b, 16) for b in expected.strip().split()]
                status = "Fail"
                failure_reason = "-"
                timestamp = time.strftime('%H:%M:%S', time.localtime())
                response_timestamp = timestamp

                try:
                    response = None
                    if service_int == 0x10:
                        response = client.change_session(subfunc_int)
                    elif service_int == 0x11:
                        response = client.ecu_reset(subfunc_int)
                    elif service_int == 0x22:
                        response = client.read_data_by_identifier(subfunc_int)
                    else:
                        raise ValueError(f"Unsupported service: {service}")

                    response_timestamp = time.strftime('%H:%M:%S', time.localtime())

                    if not response.positive:
                        failure_reason = f"NRC: {hex(response.code)}"
                    else:
                        actual_bytes = list(response.original_payload)
                        if actual_bytes[:len(expected_bytes)] == expected_bytes:
                            status = "Pass"
                        else:
                            failure_reason = (
                                f"Expected: {' '.join(format(b, '02X') for b in expected_bytes)}, "
                                f"Got: {' '.join(format(b, '02X') for b in actual_bytes)}"
                            )

                except Exception as e:
                    response_timestamp = time.strftime('%H:%M:%S', time.localtime())
                    failure_reason = str(e)

                # OLED display update
                display_msg = f"{tc_id}\n{step_desc[:50]}\n{status}"
                display_text(display_msg)
                time.sleep(2)

                if status == "Fail":
                    display_text(f"FAILED\n{failure_reason[:20]}", y=0)
                    time.sleep(2)

                report.append({
                    "id": tc_id,
                    "timestamp": timestamp,
                    "response_timestamp": response_timestamp,
                    "description": step_desc,
                    "type": "Request Sent",
                    "status": status,
                    "failure_reason": failure_reason
                })

    filename = f"UDS_Report_{int(time.time())}.html"
    generate_report(convert_report(report), filename=filename)
    display_text("Report Done!\n" + filename[:16])
    import can
import isotp
import time
import logging
import csv
import threading

from udsoncan.client import Client
from udsoncan.connections import PythonIsoTpConnection
from udsoncan.configs import default_client_config
from udsoncan.exceptions import TimeoutException, NegativeResponseException

from report_generator import generate_report
from oled_display import display_text

class UDSClient:
    def __init__(self, config):
        can_cfg = config['uds']['can']
        isotp_cfg = config['uds']['isotp']
        timing_cfg = config['uds']['timing']
        self.uds_config = config['uds']

        self.tx_id = int(can_cfg['tx_id'], 16)
        self.rx_id = int(can_cfg['rx_id'], 16)
        self.channel = can_cfg['channel']
        self.iface = can_cfg['interface']
        self.enable_tester_present = config['uds'].get("enable_tester_present", True)

        self.bus = can.interface.Bus(channel=self.channel, bustype=self.iface, fd=can_cfg.get('can_fd', False))

        addr_mode = isotp.AddressingMode.Extended_29bits if can_cfg.get('is_extended') else isotp.AddressingMode.Normal_11bits
        address = isotp.Address(addr_mode, txid=self.tx_id, rxid=self.rx_id)

        self.stack = isotp.CanStack(bus=self.bus, address=address, params=isotp_cfg)
        self.conn = PythonIsoTpConnection(self.stack)

        self.start_time = time.time()

        self.client_config = default_client_config.copy()
        self.client_config['p2_timeout'] = timing_cfg.get('p2_client', 500) / 1000.0
        self.client_config['p2_star_timeout'] = timing_cfg.get('p2_extended_client', 5000) / 1000.0
        self.client_config['s3_client_timeout'] = timing_cfg.get('s3_client', 3000) / 1000.0

        self._tester_present_running = False
        self._tester_thread = None

    def get_canoe_timestamp(self):
        return f"{time.time() - self.start_time:.6f}"

    def _tester_present_loop(self, client, interval=2):
        while self._tester_present_running:
            try:
                client.tester_present()
                logging.debug("Tester Present sent (loop)")
            except Exception as e:
                logging.warning(f"Tester Present loop error: {e}")
            time.sleep(interval)

    def start_tester_present_loop(self, client):
        self._tester_present_running = True
        self._tester_thread = threading.Thread(target=self._tester_present_loop, args=(client,))
        self._tester_thread.daemon = True
        self._tester_thread.start()

    def stop_tester_present_loop(self):
        self._tester_present_running = False
        if self._tester_thread and self._tester_thread.is_alive():
            self._tester_thread.join()

     def get_ecu_information(self):
    tester_present = int(self.uds_config.get("tester_present"), 16)
    default_session = int(self.uds_config.get("default_session"), 16)
    extended_session = int(self.uds_config.get("extended_session"), 16)
    dids = self.uds_config.get("data_identifiers", {})

    self.send_raw([0x3E, 0x00])  # Tester Present
    self.send_raw([0x10, default_session])
    self.send_raw([0x10, extended_session])

    for did_hex in dids:
        did = int(did_hex, 16)
        response = self.send_raw([0x22, (did >> 8) & 0xFF, did & 0xFF])
        display_value = response[3:] if response else "No Resp"
        self.oled.display_text(f"{dids[did_hex]}: {display_value}")
        time.sleep(1)
    

    
    def run_testcase(self, grouped_cases):
    report = []
    with Client(self.conn, request_timeout=2, config=self.client_config) as client:
        client.change_session(0x03)

        for tc_id, steps in grouped_cases.items():
            for step in steps:
                _, step_desc, service, subfunc, expected = step

                try:
                    service_int = int(service, 16)
                    subfunc_int = int(subfunc, 16)
                    expected_bytes = [int(b, 16) for b in expected.strip().split()]
                except ValueError:
                    logging.warning(f"Skipping malformed test case: {step}")
                    continue

                status = "Fail"
                failure_reason = "-"
                timestamp = time.strftime('%H:%M:%S')

                try:
                    if service_int == 0x10:
                        response = client.change_session(subfunc_int)
                    elif service_int == 0x11:
                        response = client.ecu_reset(subfunc_int)
                    elif service_int == 0x22:
                        response = client.read_data_by_identifier(subfunc_int)
                    else:
                        raise ValueError(f"Unsupported service: {service}")

                    if not response.positive:
                        failure_reason = f"NRC: {hex(response.code)}"
                    else:
                        actual_bytes = list(response.original_payload)
                        if actual_bytes[:len(expected_bytes)] == expected_bytes:
                            status = "Pass"
                        else:
                            failure_reason = (
                                f"Expected: {' '.join(format(b, '02X') for b in expected_bytes)}, "
                                f"Got: {' '.join(format(b, '02X') for b in actual_bytes)}"
                            )

                except Exception as e:
                    failure_reason = str(e)

                if self.oled:
                    self.oled.display_text(f"{tc_id}\n{step_desc[:50]}\n{status}")
                    time.sleep(2)
                    if status == "Fail":
                        self.oled.display_text(f"FAILED\n{failure_reason[:20]}")
                        time.sleep(2)

                report.append({
                    "id": tc_id,
                    "timestamp": timestamp,
                    "description": step_desc,
                    "type": "Request Sent",
                    "status": status,
                    "failure_reason": failure_reason
                })

    filename = f"UDS_Report_{int(time.time())}.html"
    generate_report(convert_report(report), filename=filename)
    if self.oled:
        self.oled.display_text("Report Done!\n" + filename[:16])

    