import logging
import time
import os
import RPi.GPIO as GPIO
from modules import button_input, oled_display, uds_client, config_loader, Parse_handler, transfer_handler
from modules.report_generator import ReportGenerator

# Load configuration
config = config_loader.load_config("config.json")
menu_combinations = config.get("menu_combinations", {})
oled_config = config.get("display", {})
can_config = config.get("uds", {}).get("can", {})
uds_config = config.get("uds", {})
isotp_config = uds_config.get("isotp", {})
report_filename = config.get("report", {}).get("filename", "uds_report.html")

# GPIO pin assignments
button_pins = config.get("gpio", {}).get("buttons", {})
BTN_FIRST = button_pins.get("first")
BTN_SECOND = button_pins.get("second")
BTN_ENTER = button_pins.get("enter")
BTN_THANKS = button_pins.get("thanks")

# Initialize components
oled = oled_display.OLEDDisplay(oled_config)
buttons = button_input.ButtonInput([BTN_FIRST, BTN_SECOND, BTN_ENTER, BTN_THANKS])
uds = uds_client.UDSClient(config=config, oled=oled)
report = ReportGenerator(report_filename)

def show_text(text, y=0):
    oled.clear()
    oled.display_text(text, y)

# Welcome screen
show_text("   Welcome to\n  Diagnostics")
time.sleep(2)

# Menu loop
variable = 0
selected_sequence = []
while True:
    show_text("Select Option:\n1.ECU Info\n2.Testcases\n3.Flash\n4.USB\n5.Reserved")
    while True:
        if GPIO.input(BTN_FIRST) == GPIO.LOW:
            variable = (variable * 10) + 1
            selected_sequence.append(BTN_FIRST)
            show_text(str(variable))

        if GPIO.input(BTN_SECOND) == GPIO.LOW:
            variable = (variable * 10) + 2
            selected_sequence.append(BTN_SECOND)
            show_text(str(variable))

        if GPIO.input(BTN_ENTER) == GPIO.LOW:
            key = str(tuple(selected_sequence))
            selected_option = menu_combinations.get(key, "Invalid Input")
            show_text(f"{selected_option}")
            time.sleep(0.5)

            if selected_option == "ECU Information":
                show_text("Fetching\nECU Info...")
                uds.get_ecu_information()
                show_text("Done")
                time.sleep(2)

            elif selected_option == "Testcase Execution":
                show_text("Parsing\nTestcases...")
                grouped_cases = Parse_handler.load_testcases("testcases.txt")
                show_text("Running...\nTestcases")
                uds.run_testcase(grouped_cases)
                show_text("Done")
                time.sleep(2)
                show_text("HTML Report\nGenerated")
                time.sleep(2)

            elif selected_option == "File Transfer\ncopying log files\nto USB device":
                show_text("File transfer...")
                transfer_handler.transfer_files_to_usb()
                show_text("Done")
                time.sleep(2)

            elif selected_option == "Exit":
                show_text("Exiting...")
                time.sleep(1)
                os.system("exit")

            selected_sequence.clear()
            variable = 0

        if GPIO.input(BTN_THANKS) == GPIO.LOW:
            show_text("Shutting Down")
            time.sleep(0.5)
            os.system("sudo poweroff")

        time.sleep(0.1)
