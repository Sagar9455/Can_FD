import time
from PIL import Image, ImageDraw, ImageFont
import board
import adafruit_ssd1306

# Setup I2C and OLED
i2c = board.I2C()
oled = adafruit_ssd1306.SSD1306_I2C(128, 64, i2c)
oled.fill(0)
oled.show()

def display_multiline_text(oled, lines, delay=2):
    width = oled.width
    height = oled.height
    font = ImageFont.load_default()
    lines_per_screen = 4
    chars_per_line = 16

    wrapped_lines = []
    for line in lines:
        while len(line) > chars_per_line:
            wrapped_lines.append(line[:chars_per_line])
            line = line[chars_per_line:]
        wrapped_lines.append(line)

    for i in range(0, len(wrapped_lines), lines_per_screen):
        oled.fill(0)
        image = Image.new("1", (width, height))
        draw = ImageDraw.Draw(image)
        for idx, text in enumerate(wrapped_lines[i:i + lines_per_screen]):
            draw.text((0, idx * 16), text, font=font, fill=255)
        oled.image(image)
        oled.show()
        time.sleep(delay)

# Fake test case data
fake_test_data = [
    {
        "tc_id": "TC_001",
        "step": "Read VIN from ECU using DID 0xF190",
        "status": "Pass",
        "reason": "-"
    },
    {
        "tc_id": "TC_002",
        "step": "Request Seed but no response from ECU, possibly stuck",
        "status": "Fail",
        "reason": "Timeout: No response after 3 attempts"
    },
]

for test in fake_test_data:
    display_multiline_text(oled, [
        f"Test ID: {test['tc_id']}",
        f"Step: {test['step']}",
        f"Status: {test['status']}"
    ])
    if test["status"] == "Fail":
        display_multiline_text(oled, [
            f"Test ID: {test['tc_id']}",
            f"Step: {test['step']}",
            "❌ FAIL ❌",
            f"Reason: {test['reason']}"
        ])