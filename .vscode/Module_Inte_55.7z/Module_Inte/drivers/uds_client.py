import shutil 
import can
import os
import isotp
import time
import logging
from datetime import datetime
from udsoncan.client import Client
from udsoncan.connections import PythonIsoTpConnection
from udsoncan.configs import default_client_config
from drivers.Parse_handler import load_testcases
from drivers.can_logger import CANLogger
from udsoncan import AsciiCodec
from drivers.report_generator import generate_report, convert_report, ReportGenerator

class SafeAsciiCodec(AsciiCodec):
    def decode(self, data):
        try:
            return data.decode('ascii')
        except UnicodeDecodeError:
            return data.hex()

class UDSClient:
    def __init__(self, config):
        can_cfg = config["uds"]["can"]
        isotp_cfg = config["uds"]["isotp"]
        timing_cfg = config["uds"]["timing"]

        self.uds_config = config["uds"]
        print("UDS Config loaded:", self.uds_config)

        self.tx_id = int(can_cfg["tx_id"], 16)
        self.rx_id = int(can_cfg["rx_id"], 16)
        is_extended = can_cfg.get("is_extended", False)

        if is_extended:
            addr_mode = isotp.AddressingMode.Normal_29bits
        else:
            addr_mode = isotp.AddressingMode.Normal_11bits

        address = isotp.Address(
            addr_mode,
            txid=self.tx_id,
            rxid=self.rx_id
        )

        self.bus = can.interface.Bus(
            channel=can_cfg["channel"],
            bustype=can_cfg["interface"],
            fd=can_cfg.get("can_fd", True),
            can_filters=[{"can_id": self.rx_id, "can_mask": 0x7FF, "extended": False}]
        )

        self.stack = isotp.CanStack(
            bus=self.bus,
            address=address,
            params=isotp_cfg
        )

        self.conn = PythonIsoTpConnection(self.stack)

        self.client_config = default_client_config.copy()
        self.client_config["p2_timeout"] = timing_cfg["p2_client"] / 1000.0
        self.client_config["p2_star_timeout"] = timing_cfg["p2_extended_client"] / 1000.0
        self.client_config["s3_client_timeout"] = timing_cfg["s3_client"] / 1000.0
        self.client_config["exception_on_negative_response"] = False
        self.client_config["exception_on_unexpected_response"] = False
        self.client_config["exception_on_invalid_response"] = False

        self.info_dids = self.uds_config["ecu_information_dids"]
        self.decode_dids = self.uds_config["decoding_dids"]
        self.client_config["data_identifiers"] = {
            int(did_str, 16): SafeAsciiCodec(length)
            for did_str, length in self.decode_dids.items()
        }

        self.can_logger = CANLogger(channel=can_cfg["channel"], interface=can_cfg["interface"])
   
    def check_disk_space(self, min_required_mb=50):
            total, used, free = shutil.disk_usage("/")
            free_mb = free // (1024 * 1024)  # Convert to MB
            return (free_mb >= min_required_mb, free_mb)
    
    
    def start_logging(self, log_name_suffix=""):
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"CANLog_{log_name_suffix}_{timestamp}.asc"
            self.can_logger.start(filename=filename)

    def stop_logging(self):
        self.can_logger.stop()

    def get_ecu_information(self, oled):
        self.start_logging(log_name_suffix="ECU_Info")
        start_time = time.time()
        report_entries = []

        session_default = int(self.uds_config["default_session"], 16)
        session_extended = int(self.uds_config["extended_session"], 16)

        with Client(self.conn, request_timeout=2, config=self.client_config) as client:
            client.change_session(session_default)
            time.sleep(0.2)
            client.change_session(session_extended)
            time.sleep(0.2)

            for did_hex, info in self.info_dids.items():
                label = info["label"]
                did = int(did_hex, 16)

                report_entries.append({
                    "id": f"ECU_Info_{did_hex}",
                    "timestamp": time.strftime('%H:%M:%S'),
                    "description": f"Read {label} ({did_hex})",
                    "type": "Request Sent",
                    "status": "Pass",
                    "failure_reason": "-"
                })

                try:
                    response = client.read_data_by_identifier(did)
                    if response.positive:
                        values = response.service_data.values[did]
                        hex_str = ' '.join(f"{b:02X}" for b in values)
                        oled.display_text(f"{label}:\n{hex_str}")
                        print(f"[ECU Info] {label} ({did_hex}) = {hex_str}")
                        status = "Pass"
                        failure_reason = "-"
                    else:
                        status = "Fail"
                        failure_reason = f"NRC: {hex(response.code)}"
                        oled.display_text(f"{label}: NRC {hex(response.code)}")
                except Exception as e:
                    status = "Fail"
                    failure_reason = str(e)[:30]
                    oled.display_text(f"{label}: {failure_reason}")

                report_entries.append({
                    "id": f"ECU_Info_{did_hex}",
                    "timestamp": time.strftime('%H:%M:%S'),
                    "description": f"Read {label} ({did_hex})",
                    "type": "Response Received",
                    "status": status,
                    "failure_reason": failure_reason
                })

                time.sleep(2)

        duration = round(time.time() - start_time, 2)
        self.stop_logging()

        project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        report_dir = os.path.join(project_root, 'output', 'html_reports')
        os.makedirs(report_dir, exist_ok=True)
        report_filename = f"ECU_Info_Report_{int(time.time())}.html"
        report_path = os.path.join(report_dir, report_filename)

        html_report = convert_report(report_entries)
        full_log_path = self.can_logger.get_log_path() or "N/A"
        can_log_file = os.path.basename(full_log_path)
        report_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

       

        oled.display_text("Log Generated!\n")

    def run_testcase(self, oled):
        # Check disk space before logging
        min_required = 50  # Minimum required space in MB
        enough_space, free_mb = self.check_disk_space(min_required_mb=min_required)
        
        if not enough_space:
            warning_msg = f"Low Storage!\nOnly {free_mb}MB left.\nNeed {min_required}MB."
            oled.display_text(warning_msg)
            logging.warning(warning_msg)
            time.sleep(4)
            return  # Abort test case execution
        
        # Show available memory in a visual way if sufficient
        oled.display_text(f"✔ Storage OK\nFree: {free_mb} MB")
        logging.info(f"Storage check passed: {free_mb} MB available")
        time.sleep(2)  # Show storage status briefly before continuing    
        
        self.start_logging(log_name_suffix="Testcase")
        start_time = time.time()
        grouped_cases = load_testcases()
        report_entries = []

        with Client(self.conn, request_timeout=2, config=self.client_config) as client:
            for tc_id, steps in grouped_cases.items():
                logging.info(f"Running Test Case: {tc_id}")
                for step in steps:
                    _, step_desc, service, subfunc, expected = step
                    try:
                        service_int = int(service, 16)
                        subfunc_int = int(subfunc, 16)
                        expected_bytes = [int(b, 16) for b in expected.strip().split()]

                        report_entries.append({
                            "id": tc_id,
                            "timestamp": time.strftime('%H:%M:%S'),
                            "description": step_desc,
                            "type": "Request Sent",
                            "status": "Pass",
                            "failure_reason": "-"
                        })

                        response = None
                        if service_int == 0x10:
                            response = client.change_session(subfunc_int)
                        elif service_int == 0x11:
                            response = client.ecu_reset(subfunc_int)
                        elif service_int == 0x22:
                            response = client.read_data_by_identifier(subfunc_int)
                        else:
                            raise ValueError(f"Unsupported service: {service}")

                        status = "Fail"
                        failure_reason = "-"
                        if response.positive:
                            actual = list(response.original_payload)
                            if actual[:len(expected_bytes)] == expected_bytes:
                                status = "Pass"
                                logging.info(f"{tc_id} {step_desc} -> PASS")
                            else:
                                failure_reason = f"Expected {expected_bytes}, got {actual}"
                                logging.warning(f"{tc_id} {step_desc} -> FAIL - {failure_reason}")
                        else:
                            failure_reason = f"NRC: {hex(response.code)}"
                            logging.warning(f"{tc_id} {step_desc} -> FAIL - {failure_reason}")
                    except Exception as e:
                        status = "Fail"
                        failure_reason = str(e)
                        logging.error(f"{tc_id} {step_desc} -> EXCEPTION - {failure_reason}")

                    oled.display_text(f"{tc_id}\n{step_desc[:20]}\n{status}")
                    time.sleep(2)
                    if status == "Fail":
                        oled.display_text("FAIL")
                        time.sleep(2)

                    report_entries.append({
                        "id": tc_id,
                        "timestamp": time.strftime('%H:%M:%S'),
                        "description": step_desc,
                        "type": "Response Received",
                        "status": status,
                        "failure_reason": failure_reason
                    })

        duration = round(time.time() - start_time, 2)
        self.stop_logging()

        project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        report_dir = os.path.join(project_root, 'output', 'html_reports')
        os.makedirs(report_dir, exist_ok=True)
        report_filename = f"UDS_Report_{int(time.time())}.html"
        report_path = os.path.join(report_dir, report_filename)

        html_report = convert_report(report_entries)
        full_log_path = self.can_logger.get_log_path() or "N/A"
        can_log_file = os.path.basename(full_log_path)
        report_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        generate_report(
            test_cases=html_report,
            filename=report_path,
            log_filename=can_log_file,
            generated_time=report_timestamp,
            duration=duration
        )

        oled.display_text("Report Done!\n" + report_filename[:16])
        logging.info(f"Test report saved: {report_filename}")
        oled.display_text("Log Generated!\n")
